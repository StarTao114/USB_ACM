/**
  ****************************(C) COPYRIGHT 2020 NCIST****************************
  * @file       Tx2_task.c/h
  * @brief      ��λ��ͨ�������Ӿ����ݴ���
  * 			����ΪUSBͨ�ţ������м����裬���ܲ�����Ӱ��
  *
  * @note
  * @history
  *  Version    Date            Author          Modification
  *  V1.0.0     2020     		czw              1. ���
  *	 V2.0.0		2023			nzt				
  *
  @verbatim
  ==============================================================================

  ==============================================================================
  @endverbatim
  ****************************(C) COPYRIGHT 2020 NCIST****************************
  */
#include "Tx2_task.h"
#include "detect_task.h"
#include "math.h"
#include "usbd_usr.h"
#include "led.h"

extern const unsigned char CRC8_TAB_UI[256];
void PcDataClean(unsigned  char * pData, int num);
uint8_t PcDataCheck( uint8_t *pData );
//static void UART_PutChar(USART_TypeDef* USARTx, u8 ch);
static void Send_to_PC(USART_TypeDef* USARTx, Send_Tx2_t *SEND_PC);
static void Interactive_data_update(Inter_Data_t *Inter_measure);
static PC_Ctrl_Union_t PcData;
PC_Send_data Data_send;
extern QueueHandle_t TxCOM6;
extern QueueHandle_t RxCOM6;
extern u8 GFlag_state;
int QFlag_state, last_QFlag_state, last_GFlag_state;
extern float re_yaw_absolute_angle;
extern float re_pitch_relative_angle;
Send_Tx2_t TX_vision_Mes;
Inter_Data_t InterUpdate;
uint32_t TxTaskStack;
uint32_t sendTaskStack;
int tim=0;
extern ext_game_robot_status_t			  	GameRobotStat;				//0x0201
extern vu8 bDeviceState;		//USB���� ���

typedef union{
	float 	data_f;
	char	data_c[4];
}float2char;


void Tx2_task(void  *pvParameters)
{
//	u8 len;	
	u8 usbstatus=0;	
    while(1)
    {
		if(usbstatus!=bDeviceState)//USB����״̬�����˸ı�.
		{
			usbstatus=bDeviceState;//��¼�µ�״̬
			if(usbstatus==1)
			{
				LED4(ON);//DS1��
			}
			else
			{
				LED4(OFF);//DS1��
			}
		} 
		if(USB_USART_RX_STA&0x8000)
		{				
			
			if(verify_crc8_check_sum(&USB_USART_RX_BUF[1], 13) != NULL)
			{
				memcpy(PcData.PcDataArray,USB_USART_RX_BUF, MINIPC_FRAME_LENGTH);
				InterUpdate.now_pc_pitch_ref=PcData.PcDate .angle_pitch ;
				InterUpdate.now_pc_yaw_ref =PcData.PcDate .angle_yaw ;
				if(InterUpdate.last_pc_yaw_ref !=InterUpdate.now_pc_yaw_ref ||InterUpdate.last_pc_pitch_ref !=InterUpdate.now_pc_pitch_ref)
				{
					InterUpdate.last_pc_yaw_ref=InterUpdate.now_pc_yaw_ref;
					InterUpdate.last_pc_pitch_ref=InterUpdate.now_pc_pitch_ref;
				}
			}
//			len=USB_USART_RX_STA&0x3FFF;//�õ��˴ν��յ������ݳ���
			USB_USART_RX_STA=0;
			DetectHook(TX2DataWGD);				//���ճɹ���ι��
		}

		
		TxTaskStack = uxTaskGetStackHighWaterMark(NULL);
		vTaskDelay(1);
    }
}


float last_relative_angle=0,err_angle=0;
int count=0;
void Interactive_task(void  *pvParameters)
{
	TX_vision_Mes.yaw.y=0;
	TX_vision_Mes.pitch.p = 0;
    while(1)
    {
		TX_vision_Mes.yaw.y 	= re_yaw_absolute_angle; //��ȡyaw
		TX_vision_Mes.pitch.p 	= re_pitch_relative_angle; //��ȡpitch
        Interactive_data_update(&InterUpdate);//��ɫ
//		TX_vision_Mes.selfid 	= GameRobotStat.robot_id;
		TX_vision_Mes.mode 		= 0;
		TX_vision_Mes.speed 	= GameRobotStat.shooter_id1_17mm_speed_limit;
        Send_to_PC(USART6, &TX_vision_Mes);	
		
        vTaskDelay(1);
    }
}

//�Ӿ��������ݸ���
static void Interactive_data_update(Inter_Data_t *Inter_measure)
{
    Inter_measure->GameRobot_State_measure = get_game_robot_state_t();
    Inter_measure->gameshoot_state_measure = get_shoot_data_t();

    if (Inter_measure->GameRobot_State_measure->robot_id > 10)
    {
        TX_vision_Mes.color = BLUE;//������ɫ
    }
    else
    {
        TX_vision_Mes.color = RED;//������ɫ
    }
}

//����PC���ն˱�����ַ��ͨ��ָ�뷽ʽ��ȡԭʼ����-----ͨ���������ݿ�����̨
const PC_Ctrl_Union_t *get_PC_Ctrl_Measure_Point(void)
{
    return &PcData;
}

//PC����У�麯��
uint8_t PcDataCheck( uint8_t *pData )
{
    if((pData[0] == 0xA5) && (pData[MINIPC_FRAME_LENGTH - 1] == 0x5A))
    {
        return 1;
    }
    else
    {
        return 0;
    }
}
//��������
void PcDataClean(unsigned  char * pData, int num)
{
    if(pData == NULL)
    {
        return;
    }

    int i = 0;

    for(i = 0; i < num; i++)
    {
        pData[i] = 0;
    }
}
unsigned char le[12];


static void Send_to_PC(USART_TypeDef* USARTx, Send_Tx2_t *TXmessage)
{
	unsigned char crc = 0;
    unsigned char *TX_data;
    TX_data = (unsigned char*)TXmessage;
    crc = get_crc8_check_sum(TX_data, 11, 0xff); //CRCУ��
    TXmessage->CRC8 = crc;
    //���ݷ��� 
    VCP_DataTx(0x5a);//֡ͷ
	
	VCP_DataTx(TXmessage->pitch.pitch_t[0]); 	//0xaa + ���� + 0xbb
	VCP_DataTx(TXmessage->pitch.pitch_t[1]);
	VCP_DataTx(TXmessage->pitch.pitch_t[2]);
	VCP_DataTx(TXmessage->pitch.pitch_t[3]);
	
	VCP_DataTx(TXmessage->yaw.yaw_t[0]);
	VCP_DataTx(TXmessage->yaw.yaw_t[1]);
	VCP_DataTx(TXmessage->yaw.yaw_t[2]);
	VCP_DataTx(TXmessage->yaw.yaw_t[3]);
	
	VCP_DataTx(TXmessage->mode);
	VCP_DataTx(TXmessage->color);
	VCP_DataTx(TXmessage->speed);
//	VCP_DataTx(TXmessage->selfid);
	
	VCP_DataTx(TXmessage->CRC8);//֡β
}

// static void UART_PutChar(USART_TypeDef* USARTx, u8 ch)
//{
//    USART_SendData(USARTx, (u8)ch);

//    while(USART_GetFlagStatus(USARTx, USART_FLAG_TXE) == RESET);
//}
















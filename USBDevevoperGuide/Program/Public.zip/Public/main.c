/**
  ****************************(C) COPYRIGHT 2023 NCIST****************************
  * @file       main.c/h
  * @brief
  * @note
  * @history
  *  Version    Date            Author          Modification
  *  V2.0.0     	2023     			STORMS       1. ���
  *
  @verbatim
  ==============================================================================
  ==============================================================================
  @endverbatim
  ****************************(C) COPYRIGHT 2023 NCIST  ****************************
  */
#include "main.h"



int main(void)
{	
    BSP_Init();
		delay_ms(50);
    startTask();
    while(1);
}

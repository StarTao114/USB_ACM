
#include "SerialPort.h"
#include "stdio.h"
#include <iostream>
#include <sys/time.h>


int main()
{

    //定义串口
    Uart              InfoPort;
    HostComputerData  RobotInfo;
    GroundChassisData MainControlInfo;
    int               fd_serial0 = 0;
    InfoPort.Init_serial(fd_serial0, 115200);
    while (1)
    {
        InfoPort.GetMode(fd_serial0, MainControlInfo);
        std::cout << "原始pitch:" << MainControlInfo.gain_pitch.f << std::endl;
        std::cout << "get1: " << int(MainControlInfo.gain_pitch.c[0]) << std::endl;
        std::cout << "get2: " << int(MainControlInfo.gain_pitch.c[1]) << std::endl;
        std::cout << "get3: " << int(MainControlInfo.gain_pitch.c[2]) << std::endl;
        std::cout << "get4: " << int(MainControlInfo.gain_pitch.c[3]) << std::endl;
        // RobotInfo.Pitch.f = aim_pitch;
        usleep(10);
        std::cout<<"1111"<<std::endl;
        InfoPort.TransformTarPos(fd_serial0, RobotInfo);  //发送数据
    }
    return 0;
}


#include "SerialPort.h"
#include "stdio.h"
#include <iostream>
//#include <opencv4/opencv2/opencv.hpp>
#include <sys/time.h>


int main()
{
    //    //运行迈德威视相机
    //    MindvisionCamera MindvisionCamera;
    //    MindvisionCamera.runCamera();

    //定义串口
    Uart              InfoPort;
    HostComputerData  RobotInfo;
    GroundChassisData MainControlInfo;
    int               fd_serial0 = 0;
    InfoPort.Init_serial(fd_serial0, 115200);
    while (1)
    {
        InfoPort.GetMode(fd_serial0, MainControlInfo);
        std::cout << "原始pitch:" << MainControlInfo.gain_pitch.f << std::endl;
        std::cout << "get1: " << int(MainControlInfo.gain_pitch.c[0]) << std::endl;
        std::cout << "get2: " << int(MainControlInfo.gain_pitch.c[1]) << std::endl;
        std::cout << "get3: " << int(MainControlInfo.gain_pitch.c[2]) << std::endl;
        std::cout << "get4: " << int(MainControlInfo.gain_pitch.c[3]) << std::endl;
        // RobotInfo.Pitch.f = aim_pitch;
        usleep(10);
        std::cout<<"1111"<<std::endl;
        InfoPort.TransformTarPos(fd_serial0, RobotInfo);  //发送数据
    }
    return 0;
}

/*
int main()
{
    //    //运行迈德威视相机
    //    MindvisionCamera MindvisionCamera;
    //    MindvisionCamera.runCamera();

    //定义串口
    Uart              InfoPort;
    HostComputerData  RobotInfo;
    GroundChassisData MainControlInfo;
    int               fd_serial0 = 0;
    InfoPort.Init_serial(fd_serial0, 115200);

    //    //包含识别到的对方数据
    //    //定义检测类对象
    //    ArmorDetetion armordetetion;  //初始化了dnn 以及目标string

    //    //定义测量类对象
    //    Survey surver;  //初始化相机内参

    //    //定义弹道模型
    //    Trajectory trajectory;

    //    //___________计算时间所需函数_________________
    //    struct timeval t1, t2;
    //    double         timeuse;
    //    //_________________________________________

    //    //___________发射所需变量____________________
    //    double aim_pitch;
    //    double aim_yaw;

    //    double aim_x;
    //    double aim_y;
    //    double aim_z;
    //    //_________________________________________

    //    /*拓展卡尔曼模型*/
//    /********************************************************************************************************************************************************/
//    double   max_match_distance = 0.2;
//    int      tracking_threshold = 5;
//    int      lost_threshold     = 5;
//    Tracker  tracker(max_match_distance, tracking_threshold, lost_threshold);  //初始化追踪器属性 最大匹配距离，追踪振阈值 丢失帧阈值
//    Tracker* tracker_ = &tracker;

//    // EKF
//    // xa = x_armor, xc = x_robot_center
//    // state: xc, yc, zc, yaw, v_xc, v_yc, v_zc, v_yaw, r
//    // measurement: xa, ya, za, yaw
//    // f - Process function
//    double dt_ = 0.0;
//    auto   f   = [&dt_](const Eigen::VectorXd& x) {
//        Eigen::VectorXd x_new = x;
//        x_new(0) += x(4) * dt_;
//        x_new(1) += x(5) * dt_;
//        x_new(2) += x(6) * dt_;
//        x_new(3) += x(7) * dt_;
//        return x_new;
//    };

//    // J_f - Jacobian of process function
//    auto j_f = [&dt_](const Eigen::VectorXd&) {
//        Eigen::MatrixXd f(9, 9);
//        // clang-format off
//               f <<  1,   0,   0,   0,   dt_, 0,   0,   0,   0,
//                     0,   1,   0,   0,   0,   dt_, 0,   0,   0,
//                     0,   0,   1,   0,   0,   0,   dt_, 0,   0,
//                     0,   0,   0,   1,   0,   0,   0,   dt_, 0,
//                     0,   0,   0,   0,   1,   0,   0,   0,   0,
//                     0,   0,   0,   0,   0,   1,   0,   0,   0,
//                     0,   0,   0,   0,   0,   0,   1,   0,   0,
//                     0,   0,   0,   0,   0,   0,   0,   1,   0,
//                     0,   0,   0,   0,   0,   0,   0,   0,   1;
//        // clang-format on
//        return f;
//    };

//    // h - Observation function
//    auto h = [](const Eigen::VectorXd& x) {
//        Eigen::VectorXd z(4);
//        double          xc = x(0), yc = x(1), yaw = x(3), r = x(8);
//        z(0) = xc - r * cos(yaw);  // xa
//        z(1) = yc - r * sin(yaw);  // ya
//        z(2) = x(2);               // za
//        z(3) = x(3);               // yaw
//        return z;
//    };

//    // J_h - Jacobian of observation function
//    auto j_h = [](const Eigen::VectorXd& x) {
//        Eigen::MatrixXd h(4, 9);
//        double          yaw = x(3), r = x(8);
//        // clang-format off
//               //    xc   yc   zc   yaw         vxc  vyc  vzc  vyaw r
//               h <<  1,   0,   0,   r*sin(yaw), 0,   0,   0,   0,   -cos(yaw),
//                     0,   1,   0,   -r*cos(yaw),0,   0,   0,   0,   -sin(yaw),
//                     0,   0,   1,   0,          0,   0,   0,   0,   0,
//                     0,   0,   0,   1,          0,   0,   0,   0,   0;
//        // clang-format on
//        return h;
//    };

//    // Q - process noise covariance matrix
//    auto q_v = std::vector<double>{ // xc  yc    zc    yaw   vxc   vyc   vzc   vyaw  r
//                                    1e-2, 1e-2, 1e-2, 2e-2, 5e-2, 5e-2, 1e-4, 4e-2, 1e-3
//    };
//    Eigen::DiagonalMatrix<double, 9> q;
//    q.diagonal() << q_v[0], q_v[1], q_v[2], q_v[3], q_v[4], q_v[5], q_v[6], q_v[7], q_v[8];  // diagonal 主对角线

//    // R - measurement noise covariance matrix
//    auto r_v = std::vector<double>{ // xa  ya    za    yaw
//                                    1e-1, 1e-1, 1e-1, 2e-1
//    };

//    Eigen::DiagonalMatrix<double, 4> r;
//    r.diagonal() << r_v[0], r_v[1], r_v[2], r_v[3];

//    // P - error estimate covariance matrix
//    Eigen::DiagonalMatrix<double, 9> p0;
//    p0.setIdentity();

//    tracker_->ekf = ExtendedKalmanFilter{ f, h, j_f, j_h, q, r, p0 };  //初始化拓展卡尔曼参数
//    /************************************************************************************************************//
/*
while (1)
{

    //        gettimeofday(&t1, nullptr);

    //        //从相机中获取图像
    //        MindvisionCamera.Do();
    //        MindvisionCamera.getImage(src);

    //接收数据
    InfoPort.GetMode(fd_serial0, MainControlInfo);

    //        //从串口中获取敌方机器人模式
    //        if (static_cast<int>(MainControlInfo.color) == 0 || static_cast<int>(MainControlInfo.color) == 1)
    //        {
    //            if (static_cast<int>(MainControlInfo.color) == 0)
    //            {
    //                armordetetion.enemy_color = Red;
    //            }
    //            if (static_cast<int>(MainControlInfo.color) == 1)
    //            {
    //                armordetetion.enemy_color = Blue;
    //            }
    //        }

    //        //定义检测类对象
    //        // 1.创建图像预处理滑块条，进行图像预处理  ->Mat Dst_Mix
    //        // 2.寻找灯条    ->vector<Light> found_lights
    //        // 3.匹配装甲板   ->vector<Armor> found_armors
    //        // 4.数字识别器   （送进仿射变换中图像偏移需要调参，二值化处理方法需要优化）
    //        // 5.确定正确装甲板   ->vector<Armor> target_armors   (训练数字处的置信度可能需要调整）
    //        // 6.确定击打目标
    //        armordetetion.ArmorDeteted(src);

    //        /******************************************************************/
//        //目的就是为了检测串口有没有问题
//        std::cout << "原始yaw:" << MainControlInfo.gain_yaw.f << std::endl;
// std::cout << "原始pitch:" << MainControlInfo.gain_pitch.f << std::endl;
//        /******************************************************************/

//        // pnp解算装甲板距离
//        // 1.根据识别到的数字确定大小装甲板 -> 设置世界坐标系的点坐标
//        // 2.pnp解算
//        // 3.坐标变换 计算装甲板中心到图像中心的距离

//        for (auto target_armor : armordetetion.target_armors)
//        {
//            surver.DistanceSolver(target_armor, MainControlInfo.gain_yaw.f, MainControlInfo.gain_pitch.f);
//            //__________________________________________________________________________________________
//            std::string armor_distence = std::to_string(target_armor.distance);
//            putText(src, armor_distence, cv::Point2f(target_armor.left_light.top.x, target_armor.left_light.top.y - 20), cv::FONT_HERSHEY_SIMPLEX, 0.5, cv::Scalar(165, 155, 238), 1);
//            // std::cout<<"变换后的坐标距离"<<
//            std::string x = std::to_string(target_armor.pose_tramsformer.translation().x());
//            std::string y = std::to_string(target_armor.pose_tramsformer.translation().y());
//            std::string z = std::to_string(target_armor.pose_tramsformer.translation().z());
//            putText(src, x, cv::Point2f(target_armor.center.x + 40, target_armor.center.y), cv::FONT_HERSHEY_SIMPLEX, 0.5, cv::Scalar(165, 155, 238), 1);
//            putText(src, ",", cv::Point2f(target_armor.center.x + 40, target_armor.center.y), cv::FONT_HERSHEY_SIMPLEX, 0.5, cv::Scalar(165, 155, 238), 1);
//            putText(src, y, cv::Point2f(target_armor.center.x + 40, target_armor.center.y + 10), cv::FONT_HERSHEY_SIMPLEX, 0.5, cv::Scalar(165, 155, 238), 1);
//            putText(src, ",", cv::Point2f(target_armor.center.x + 40, target_armor.center.y + 20), cv::FONT_HERSHEY_SIMPLEX, 0.5, cv::Scalar(165, 155, 238), 1);
//            putText(src, z, cv::Point2f(target_armor.center.x + 40, target_armor.center.y + 30), cv::FONT_HERSHEY_SIMPLEX, 0.5, cv::Scalar(165, 155, 238), 1);
//            //__________________________________________________________________________________________
//        }

//        //将目标装甲板送进追踪器
//        for (auto target_armor : armordetetion.target_armors)
//        {
//            tracker_->armors_to_tracke.push_back(target_armor);
//        }

//        gettimeofday(&t2, nullptr);

//        // 1.确定最靠近图像中心的装甲板
//        // 2.初始化卡尔曼
//        // 3.预测
//        // 4.更新
//        if (tracker_->tracker_state == Tracker::LOST)
//        {
//            std::cout << "追踪器初始化" << std::endl;
//            tracker_->init(tracker_->armors_to_tracke);
//            tracker_->target.tracking = false;
//        }
//        else
//        {
//            std::cout << "更新追踪器" << std::endl;
//            dt_ = (t2.tv_sec - t1.tv_sec) + ( double )(t2.tv_usec - t1.tv_usec) / 1000000;  // s
//            tracker_->update(tracker_->armors_to_tracke);
//            if (tracker_->tracker_state == Tracker::DETECTING)
//            {
//                std::cout << "追踪器为检测" << std::endl;
//                tracker_->target.tracking = false;
//            }
//            else if (tracker_->tracker_state == Tracker::TRACKING || tracker_->tracker_state == Tracker::TEMP_LOST)
//            {
//                std::cout << "追踪器为追踪" << std::endl;
//                tracker_->target.tracking = true;
//                tracker_->target.id       = tracker_->tracked_id;
//            }
//        }

//        //*********************************************************************************************************************
//        //计算弹道   （向电控发送 yaw 和pitch）

//        if (tracker_->target.tracking == true)
//        {
//            std::cout << "xw" << tracker_->target_state(0) << std::endl;
//            std::cout << "yw" << tracker_->target_state(1) << std::endl;
//            std::cout << "zw" << tracker_->target_state(2) << std::endl;
//            std::cout << "tar_yaw" << tracker_->target_state(3) << std::endl;
//            std::cout << "vxw" << tracker_->target_state(4) << std::endl;
//            std::cout << "vyw" << tracker_->target_state(5) << std::endl;
//            std::cout << "vzw" << tracker_->target_state(6) << std::endl;
//            std::cout << "v_yaw" << tracker_->target_state(7) << std::endl;
//            std::cout << "r" << tracker_->target_state(8) << std::endl;

//            trajectory.st.k = 0.092;

//            trajectory.st.bullet_type = Trajectory::BULLET_17;
//            ;
//            trajectory.st.current_v   = 30;
//            trajectory.st.current_yaw = MainControlInfo.gain_yaw.f;
//            trajectory.st.current_yaw = MainControlInfo.gain_pitch.f;

//            trajectory.st.xw      = tracker_->target_state(0);
//            trajectory.st.yw      = tracker_->target_state(1);
//            trajectory.st.zw      = tracker_->target_state(2);
//            trajectory.st.tar_yaw = tracker_->target_state(3);

//            trajectory.st.vxw   = tracker_->target_state(4);
//            trajectory.st.vyw   = tracker_->target_state(5);
//            trajectory.st.vzw   = tracker_->target_state(6);
//            trajectory.st.v_yaw = tracker_->target_state(7);

//            trajectory.st.r1 = tracker_->target_state(8);
//            trajectory.st.r2 = tracker_->last_r;

//            trajectory.st.dz = 0.01;

//            trajectory.st.bias_time;
//            trajectory.st.s_bias = 0.19;
//            trajectory.st.z_bias = 0.21;

//            trajectory.st.armor_id  = Trajectory::ARMOR_INFANTRY3;
//            trajectory.st.armor_num = Trajectory::ARMOR_NUM_NORMAL;

//            trajectory.autoSolveTrajectory(&aim_pitch, &aim_yaw, &aim_x, &aim_y, &aim_z);
//        }
// RobotInfo.Pitch.f = 3.5f;
// RobotInfo.Pitch.f = aim_pitch;

// InfoPort.TransformTarPos(fd_serial0, RobotInfo);  //发送数据

//***********************************************************************************************************************

//        cv::imshow("srcimg", src);
//        src.release();
//        /**********按下空格暂停***********/
//        char key = static_cast<char>(cv::waitKey(25));
//        if (key == 'q' || key == 'Q')
//        {

//            CameraStop(MindvisionCamera.hCamera);
//            break;
//        }
//        else if (key == 32)
//        {
//            while (cv::waitKey(0) != 32)
//                cv::waitKey(0);
//        }
//}

//    CameraUnInit(MindvisionCamera.hCamera);
//    //注意，现反初始化后再free
//    free(MindvisionCamera.g_pRgbBuffer);

// return 0;
//}
